﻿#include "Silnik.h"

/**
 * @brief Główna funkcja programu.
 * @return Kod zakończenia programu.
 */
int main() {
    Silnik silnik;
    silnik.uruchom();

    return 0;
}
